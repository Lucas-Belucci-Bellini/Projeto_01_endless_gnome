extends Node2D
class_name WorlTest

@onready var camera := $Camera
@onready var gnomo_player := $Gnomo

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	camera.position = gnomo_player.global_position
